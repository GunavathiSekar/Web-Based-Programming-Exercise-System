define(function(require, exports, module) {

exports.isDark = true;
exports.cssClass = "ace-twilight";
exports.cssText = require("resources/css/twilight.css");

var dom = require("../lib/dom");
dom.importCssString(exports.cssText, exports.cssClass);
});