package com.login;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class savefile
 */
@WebServlet("/savefile")
public class savefile extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		BufferedWriter bw = null;
		FileWriter fw = null;
        System.out.println(request.getParameter("content"));
		try {
			   String program=request.getParameter("program");  
			   String content = request.getParameter("content");
			   String replaceString;
			   String[] contentsplit=content.split(" ");
			   content=" ";
			   for (int i = 1; i < contentsplit.length; i++) {
				content+=" "+contentsplit[i];
			
			     }
			   replaceString=content.replace("X","");
			   System.out.println(replaceString);
			   if(program.equalsIgnoreCase("java"))
			 {

			fw = new FileWriter("D:\\ec_workspace\\loginproject\\WebContent\\resources\\files\\Solution.java");
			bw = new BufferedWriter(fw);
			bw.write(replaceString);
			System.out.println("Done");
			System.out.println("**********");
            runProcess("javac -cp src src/com/problem/Solution.java");
            System.out.println("**********");
            runProcess("java -cp src com/problem/Solution");
			   }
			   else if(program.equalsIgnoreCase("cpp"))
			   {
				   System.out.println(replaceString);
				   System.out.println(program);
				   fw = new FileWriter("D:\\ec_workspace\\loginproject\\WebContent\\resources\\files\\main.cpp");
					bw = new BufferedWriter(fw);
					bw.write(replaceString);
					System.out.println("Done");
			   }
			   else if(program.equalsIgnoreCase("c")) 
			   {
				    fw = new FileWriter("D:\\ec_workspace\\loginproject\\WebContent\\resources\\files\\main.c");
					bw = new BufferedWriter(fw);
					bw.write(replaceString);
					System.out.println("Done");
					//Process p = Runtime.getRuntime().exec("cmd /C gcc" + filename + " -o " + exeName, null, dir);  
       	             //       p = Runtime.getRuntime().exec("cmd /C dir", null, dir);  
		            //BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));  
		            //String line = null;  
		           // while ((line = in.readLine()) != null)
		           // {  
		              //  System.out.println(line); 
		             //   
			          //}
			   }
			   else
			   {
				   System.out.println("no match");
			   }
			   

		} 
		catch(IOException e)
		{
			e.printStackTrace();
		}
		catch (Exception e) {

			e.printStackTrace();

		} finally {

			try {

				if (bw != null)
					bw.close();

				if (fw != null)
					fw.close();

			} catch (IOException ex) {

				ex.printStackTrace();

			}

		}

	}
	 private static void printLines(String cmd, InputStream ins) throws Exception {
	        String line = null;
	        BufferedReader in = new BufferedReader(
	            new InputStreamReader(ins));
	        while ((line = in.readLine()) != null) {
	            System.out.println(cmd + " " + line);
	        }
	      }

	      private static void runProcess(String command) throws Exception {
	        Process pro = Runtime.getRuntime().exec(command);
	        printLines(command + " stdout:", pro.getInputStream());
	        printLines(command + " stderr:", pro.getErrorStream());
	        pro.waitFor();
	        System.out.println(command + " exitValue() " + pro.exitValue());
	      }

}
