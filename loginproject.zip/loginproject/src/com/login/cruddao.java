package com.login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;



public class cruddao {
	private PreparedStatement pStmt;
	
	public void deleteCourse(int courseId) {
		String deleteQuery = "UPDATE coursetbl SET status = ? WHERE courseid = ?";
		try {
			Connection con=db.getCon();
			pStmt = con.prepareStatement(deleteQuery);
			pStmt.setInt(2, courseId);
			pStmt.setInt(1, 0);
			pStmt.executeUpdate();
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
	}

	public void updateCourse(Course c)  {
		String updateQuery = "UPDATE coursetbl SET coursename = ?, " +
				"description = ? WHERE courseid = ?";
		try {
			Connection con=db.getCon();
			pStmt = con.prepareStatement(updateQuery);		
			pStmt.setString(1,c.getCourseName());
			pStmt.setString(2,c.getDescription());
			pStmt.setInt(3, c.getCourseId());
			pStmt.executeUpdate();

		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
	}
	
	public List<Course> getAllcourselist(){
		List<Course> List=new ArrayList<Course>();
		try
		{
		Connection con=db.getCon();
		String query = "SELECT * FROM coursetbl where status=1";
		Statement stmt=con.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		while (rs.next())
		 {
			Course courselist=new Course();
			courselist.setCourseId(rs.getInt("courseid"));
			courselist.setCourseName(rs.getString("coursename"));
			courselist.setDescription(rs.getString("description"));
			List.add(courselist);
		 }
		}
		catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return List; 
	}

	public List<Course> getAllcourse(){
		List<Course> List=new ArrayList<Course>();
		try
		{
		Connection con=db.getCon();
		String query = "SELECT * FROM coursetbl";
		Statement stmt=con.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		while (rs.next())
		 {
			Course c=new Course();
			c.setCourseId(rs.getInt("courseid"));
			c.setCourseName(rs.getString("coursename"));
			List.add(c);
		 }
		//System.out.println(List);
		}
		
		catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return List; 
	}
	public java.util.List<Register> getAllUsers() {
		List<Register> List=new ArrayList<Register>();
		try
		{
		Connection con=db.getCon();
		String query = "SELECT firstname,lastname,email,status FROM register where status=1";
		Statement stmt=con.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		while (rs.next())
		 {
			Register reg=new Register();
			reg.setFirstName(rs.getString("firstname"));
			reg.setLastName(rs.getString("lastname"));
			reg.setEmailId(rs.getString("email"));
			reg.setStatus(rs.getInt("status"));
			List.add(reg);
			
		 }
		}
		catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return List; 
	}
	
	public void deleteUser(String email) {
		String deleteQuery = "UPDATE register SET status = ? WHERE email = ?";
		try {
			Connection con=db.getCon();
			pStmt = con.prepareStatement(deleteQuery);
			pStmt.setString(2, email);
			pStmt.setInt(1, 0);
			pStmt.executeUpdate();
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
	}
	
	public List<problem> getProblemlist(int id){
		List<problem> List=new ArrayList<problem>();
		String query = "SELECT * FROM problemtbl where courseid=?";
		
		try
		{
		Connection con=db.getCon();
	
		pStmt=con.prepareStatement(query);
		pStmt.setInt(1,id);
		ResultSet rs = pStmt.executeQuery();
		while (rs.next())
		 {
			problem problemlist=new problem();
			problemlist.setProblemId(rs.getInt("problemid"));
			problemlist.setCourseId(rs.getInt("courseid"));
			problemlist.setProblemName(rs.getString("problemname"));
			problemlist.setDescription(rs.getString("description"));
			problemlist.setSkeleton(rs.getString("skeleton"));
			List.add(problemlist);
		 }
		}
		catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return List; 
	}
	public java.util.List<Register> getUserDetails(String displayname) {
		List<Register> List=new ArrayList<Register>();
		try
		{
		Connection con=db.getCon();
		String query = "SELECT  * FROM register where username=?";
		pStmt=con.prepareStatement(query);
		pStmt.setString(1,displayname);
		ResultSet rs = pStmt.executeQuery();
		while (rs.next())
		 {
			Register reg=new Register();
			reg.setFirstName(rs.getString("firstname"));
			reg.setLastName(rs.getString("lastname"));
			reg.setEmailId(rs.getString("email"));
			reg.setDisplayName(rs.getString("username"));
			reg.setAlternativeEmailId(rs.getString("alternativeEmail"));
			List.add(reg);
			
		 }
		}
		catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return List; 
	}
	public List<problem> getProblemname(int id){
		List<problem> List=new ArrayList<problem>();
		String query = "SELECT problemid,problemname FROM problemtbl where courseid=?";
		
		try
		{
		Connection con=db.getCon();
	
		pStmt=con.prepareStatement(query);
		pStmt.setInt(1,id);
		ResultSet rs = pStmt.executeQuery();
		while (rs.next())
		 {
			problem problemlist=new problem();
			problemlist.setProblemId(rs.getInt("problemid"));
			problemlist.setProblemName(rs.getString("problemname"));
			List.add(problemlist);
		  }
		}
		catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return List; 
	}
	
	public List<problem> getProblemdescription(int id){
		List<problem> List=new ArrayList<problem>();
		String query = "SELECT * FROM problemtbl where problemid=?";
		
		try
		{
		Connection con=db.getCon();
	
		pStmt=con.prepareStatement(query);
		pStmt.setInt(1,id);
		ResultSet rs = pStmt.executeQuery();
		while (rs.next())
		 {
			problem problemlist=new problem();
			problemlist.setProblemName(rs.getString("description"));
			problemlist.setProblemName(rs.getString("skeleton"));
			List.add(problemlist);
		  }
		}
		catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return List; 
	}
	


}
