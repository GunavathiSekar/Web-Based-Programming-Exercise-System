package com.login;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;



/**
 * Servlet implementation class editdeleteservlet
 */
@WebServlet("/editdeleteservlet")
public class editdeleteservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private HashMap<String, Object> JSONROOT = new HashMap<String, Object>();
	private cruddao dao;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public editdeleteservlet() {
    	
    	dao = new cruddao();
            }

	
    protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		String action = request.getParameter("action");
		List<Course> CourseList = new ArrayList<Course>();
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		response.setContentType("application/json");

		if (action != null) {
			try {
				if (action.equals("list")) {
					// Fetch Data from Course Table
					CourseList = dao.getAllcourselist();

					// Return in the format required by jTable plugin
					JSONROOT.put("Result", "OK");
					JSONROOT.put("Records", CourseList);

					// Convert Java Object to Json
					String jsonArray = gson.toJson(JSONROOT);

					response.getWriter().print(jsonArray);
				} else if (action.equals("update")) {
					Course Course = new Course();
					if (request.getParameter("courseid") != null) {
						int CourseId = Integer.parseInt(request.getParameter("courseid"));
						Course.setCourseId(CourseId);
					}

					if (request.getParameter("coursename") != null) {
						String name = request.getParameter("coursename");
						Course.setCourseName(name);
					}

					if (request.getParameter("description") != null) {
						String description = request.getParameter("description");
						Course.setDescription(description);
					}

					

					 if (action.equals("update")) {
						// Update existing record
						dao.updateCourse(Course);
					}

					// Return in the format required by jTable plugin
					JSONROOT.put("Result", "OK");
					JSONROOT.put("Record", Course);

					// Convert Java Object to Json
					String jsonArray = gson.toJson(JSONROOT);
					response.getWriter().print(jsonArray);
				} else if (action.equals("delete")) {
					// Delete record
					if (request.getParameter("courseid") != null) {
						int CourseId = Integer.parseInt(request.getParameter("courseid"));
						dao.deleteCourse(CourseId);

						// Return in the format required by jTable plugin
						JSONROOT.put("Result", "OK");

						// Convert Java Object to Json
						String jsonArray = gson.toJson(JSONROOT);
						response.getWriter().print(jsonArray);
					}
				}
			} catch (Exception ex) {
				JSONROOT.put("Result", "ERROR");
				JSONROOT.put("Message", ex.getMessage());
				String error = gson.toJson(JSONROOT);
				response.getWriter().print(error);
			}
		}
	}
}