package com.login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class loginservlet
 */
@WebServlet("/loginservlet")
public class loginservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String dbUsername = null;
	String name = null;
	String dbPassword = null;
	String userstr = null;
	String passstr = null;
	String result = null;
	boolean status1 = false;
	int count = 0;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public loginservlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		try {
			userstr = request.getParameter("username");
			passstr = request.getParameter("password");
			response.setContentType("text/html");
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cloudcoder", "root", "");
			Statement stmt = con.createStatement();
			stmt.executeQuery("select email,username,password,status from register where username='" + request.getParameter("username")
					+ "' and password='" + request.getParameter("password") + "' and status=1");
			ResultSet rs = stmt.getResultSet();
			//name=rs.getString("displayname");
			HttpSession session = request.getSession();
	    	session.setAttribute("displayname1",name);
			status1 = rs.next();
			if(status1)
			{
			     if (userstr.equalsIgnoreCase("admin") && passstr.equalsIgnoreCase("guna-2015"))
			     {
				   response.getWriter().write(Boolean.toString(status1));
				  request.getRequestDispatcher("adminmenu.html").include(request, response);
			        } 
			     else
			     {
			    	  out=response.getWriter();
			    	  out.write("<span class='displayname' style='color:red'>"+rs.getString("username")+"</span>");
			    	 request.getRequestDispatcher("userMenu.html").include(request, response);	
				 }
			}
			else 
			{
					response.getWriter().write(("Invalid username/password"));
					
			}
			
			con.close();
		}

		catch (Exception ex) {
			System.out.println(ex);
		}
	}

}
