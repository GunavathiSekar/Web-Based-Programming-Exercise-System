package com.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class updateprofile
 */
@WebServlet("/updateprofile")
public class updateprofile extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private PreparedStatement pStmt;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		 PrintWriter out = response.getWriter();
		try{
	        int status;
			Connection con=db.getCon();
			String query = "UPDATE register SET firstname=?,lastname=?,email=?,username=?,alternativeEmail=?  where username=?";
			pStmt=con.prepareStatement(query);
			pStmt.setString(1,request.getParameter("firstname"));
			pStmt.setString(2,request.getParameter("lastname"));
			pStmt.setString(3,request.getParameter("email"));
			pStmt.setString(4,request.getParameter("displayname"));
			pStmt.setString(5,request.getParameter("alternativeemail"));
			pStmt.setString(6,request.getParameter("displayname"));
			status=pStmt.executeUpdate();
			if(status==1)
			{
				out.println("<script type=\"text/javascript\">");
			    out.println("alert('Profile updated successfully');");
			    out.println("</script>");
			    request.getRequestDispatcher("profile.html").include(request, response);
			}
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}

}
