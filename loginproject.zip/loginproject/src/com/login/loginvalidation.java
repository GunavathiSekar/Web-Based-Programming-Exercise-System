package com.login;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class loginvalidation
 */
@WebServlet("/loginvalidation")
public class loginvalidation extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String dbUsername=null;
	String dbPassword=null;
	String userstr=null;
	String passstr=null;
	String display=null;
	String result="fail";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public loginvalidation() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setContentType("text/html");
		 PrintWriter out = response.getWriter();
		try{
			userstr=request.getParameter("emailid");
			passstr=request.getParameter("password");
			response.setContentType("text/html");
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/cloudcoder", "root", "");
			Statement stmt=con.createStatement();
			stmt.executeQuery("select email,password from register where email='"+request.getParameter("emailid")+"' and password='"+request.getParameter("password")+"'");
			ResultSet rs = stmt.getResultSet();
			 while(rs.next())
			{
               dbUsername = rs.getString("email");
               dbPassword = rs.getString("password");
               display    = rs.getString("displayname");
             if(dbUsername.equals(userstr) && dbPassword.equals(passstr))
             {
           	  result=display;
           	  out.print(result);
 			  }
			}  
			con.close();
		} 
		catch (Exception e) {
			// TODO: handle exception
		}
	}

}
