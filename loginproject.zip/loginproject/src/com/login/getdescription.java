package com.login;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * Servlet implementation class getdescription
 */
@WebServlet("/getdescription")
public class getdescription extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private HashMap<String, Object> JSONROOT = new HashMap<String, Object>();
	private cruddao dao;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getdescription() {
    	dao = new cruddao();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<problem> Problemdescription = new ArrayList<problem>();
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		response.setContentType("application/json");
		try
		{
			System.out.print(request.getParameter("problemid"));
			problem p=new problem();
		if (request.getParameter("problemid") != null) {
		int ProblemId = Integer.parseInt(request.getParameter("problemid"));
	    p.setProblemId(ProblemId);
	    Problemdescription = dao.getProblemdescription((ProblemId));

	// Return in the format required by jTable plugin
	JSONROOT.put("Result", "OK");
	JSONROOT.put("Records", Problemdescription);

	// Convert Java Object to Json
	String jsonArray = gson.toJson(JSONROOT);

	response.getWriter().print(jsonArray);
			}
       }
		catch (Exception ex) {
			JSONROOT.put("Result", "ERROR");
			JSONROOT.put("Message", ex.getMessage());
			String error = gson.toJson(JSONROOT);
			response.getWriter().print(error);
			}


	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
