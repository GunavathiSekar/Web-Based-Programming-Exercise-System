package com.login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class getalluser
 */
@WebServlet("/getalluser")
public class getalluser extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int count=0;
		try
		{
		   Connection con=db.getCon();
		   Statement stmt=con.createStatement();
		   ResultSet rs=stmt.executeQuery("SELECT * FROM register where status=1");
		   while(rs.next()){
			  count++;
			  }
		   response.getWriter().write(Integer.toString(count));
						
			con.close();
		} 
	    catch (Exception e) {
			System.out.println("error"+e);
		}
		


		
		//return count;

	}

}
