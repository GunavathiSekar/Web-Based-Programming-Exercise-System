package com.login;

public class Register {
	
	private String firstname;
	private String lastname;
	private String email;
	private String username;
	private String password;
	private String alternativeemail;
	private int status;
	
	public String getFirstName() {
		return firstname;
	}
	public void setFirstName(String Firstname) {
		this.firstname=Firstname;
	}
	public String getLastName() {
		return lastname;
	}
	public void setLastName(String Lastname) {
		this.lastname=Lastname;
	}
	public String getEmailId() {
		return email;
	}
	public void setEmailId(String email) {
		this.email=email;
	}
	public String getDisplayName() {
		return username;
	}
	public void setDisplayName(String name) {
		this.username=name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password=password;
	}
	
	public String getAlternativeEmailId() {
		return alternativeemail;
	}
	public void setAlternativeEmailId(String email) {
		this.alternativeemail=email;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
	this.status=status;
	}


}
