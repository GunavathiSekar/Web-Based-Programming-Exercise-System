package com.login;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * Servlet implementation class Retriveuserdetails
 */
@WebServlet("/Retriveuserdetails")
public class Retriveuserdetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private HashMap<String, Object> JSONROOT = new HashMap<String, Object>();  
	private cruddao dao;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Retriveuserdetails() {
    	dao = new cruddao();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String displayname=request.getParameter("displayname");
		List<Register> List=new ArrayList<Register>();
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		response.setContentType("application/json");
		if (displayname != null) {
			try {
				List=dao.getUserDetails(displayname);
				JSONROOT.put("Result", "OK");
				JSONROOT.put("Records", List);

				// Convert Java Object to Json
				String jsonArray = gson.toJson(JSONROOT);

				response.getWriter().print(jsonArray);
				
			}
			catch(Exception e){
				System.out.println(e);}
			}
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
