package com.login;

public class Course {
	private int courseid;
	private String coursename;
	private String description;
	
	public int getCourseId() {
		return courseid;
	}
	public void setCourseId(int Courseid) {
	this.courseid=Courseid;
	}
	public String getCourseName() {
		return coursename;
	}
	public void setCourseName(String Coursename) {
		this.coursename=Coursename;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description=description;
	}

}

