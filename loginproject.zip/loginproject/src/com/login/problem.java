package com.login;

public class problem {
	
	private int problemid;
	private int courseid;
	private String problemname;
	private String description;
	private String skeleton;
	
	public int getProblemId() {
		return problemid;
	}
	public void setProblemId(int Problemid) {
	this.problemid=Problemid;
	}
	public int getCourseId() {
		return courseid;
	}
	public void setCourseId(int Courseid) {
	this.courseid=Courseid;
	}
	public String getProblemName() {
		return problemname;
	}
	public void setProblemName(String Problemname) {
		this.problemname=Problemname;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description=description;
	}
	public String getSkeleton() {
		return skeleton;
	}
	public void setSkeleton(String Skeleton) {
		this.skeleton=Skeleton;
	}
	

}
