package com.login;
import com.login.db;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class insertdb
 */
@WebServlet("/insertdb")
public class insertdb extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String dbUsername=null;
	String dbPassword=null;
	String userstr=null;
	String passstr=null;
	String result=null;
	int count=0;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public insertdb() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		 PrintWriter out = response.getWriter();
		 Boolean status=false;
		try
		{
			userstr=request.getParameter("email");
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/cloudcoder", "root", "");
			Statement stmt=con.createStatement();
			stmt.executeQuery("select email from register where username='"+request.getParameter("displayname")+"' ");
			ResultSet rs = stmt.getResultSet();
			status=rs.next();	
			if(status)
			{
		        response.getWriter().write(Boolean.toString(status));
				out.println("<script type=\"text/javascript\">");
			    out.println("alert('User name  already exists');");
			    out.println("</script>");
			}
		   else
		   {
		     stmt.executeUpdate("insert into register(firstname,lastname,email,username,password) values('"+request.getParameter("firstname")+"','"+request.getParameter("lastname")+"','"+request.getParameter("email")+"','"+request.getParameter("displayname")+"','"+request.getParameter("pass")+"')");
		     out.println("<script type=\"text/javascript\">");
			 out.println("alert('Please use your username and password to Login');");
			 out.println("</script>");
		    
		   }
			con.close();
		} 
	    catch (Exception e) {
			// TODO: handle exception
		}
	}
}

